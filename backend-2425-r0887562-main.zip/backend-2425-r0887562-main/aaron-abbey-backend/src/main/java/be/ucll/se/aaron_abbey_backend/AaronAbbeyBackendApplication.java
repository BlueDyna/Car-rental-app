package be.ucll.se.aaron_abbey_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AaronAbbeyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AaronAbbeyBackendApplication.class, args);
	}

}
