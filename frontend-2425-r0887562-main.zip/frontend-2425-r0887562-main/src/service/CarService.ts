import { Car } from "@/types";
import makeRequest from "./makeRequest";

const createCar = async (car: Car) => {
    return await makeRequest(`/cars/add`, "POST", car);
};

const getCars = async () => {
    return await makeRequest(`/cars/all`, "GET");
}

const getCarById = async (id:number ) => {
    return await makeRequest(`/cars/find/` + id, "GET");
}

const deleteCar = async (id:number) => {
    return await makeRequest(`/cars/delete/` + id, "DELETE");
}


const CarService = {
    createCar, getCars, getCarById, deleteCar
};

export default CarService;