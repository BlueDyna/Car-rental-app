const url = process.env.NEXT_PUBLIC_API_URL;

const makeRequest = async (
  endpoint: string,
  method: string,
  body?: any
): Promise<Response> => {
    const token = sessionStorage.getItem("token");
  try {
    return await fetch(url + endpoint, {
      method: method,
      headers: {
        "Content-type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (error) {
    console.error(error);
    throw error;
  }
};

export default makeRequest;