import makeRequest from "./makeRequest";

const getNotifications = async () => {
    return await makeRequest(`/notifications/all`, "GET");
}

const findNotificationById = async (id:number ) => {
    return await makeRequest(`/notifications/find/` + id, "GET");
}

const confirmYesorNo = async (id:number, isConfirmed:boolean) => {
    return await makeRequest(`/notifications/search/${id}/confirm/${isConfirmed}`, "PUT");
}



const NotificationService = {
    getNotifications, findNotificationById, confirmYesorNo
};

export default NotificationService;