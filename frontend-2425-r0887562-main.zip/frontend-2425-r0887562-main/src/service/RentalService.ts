import { Rental } from "@/types";
import makeRequest from "./makeRequest";


const createRental = async (rental: Rental, id: number) => {
    return await makeRequest(`/rentals/create/` + id, "POST", rental);
  };
  
  const getAllRentals = async () => {
    return await makeRequest(`/rentals/all`, "GET");
  };

  const getRentalById = async (id: number) => {
    return await makeRequest(`/rentals/find/` + id, "GET");
  }

  const cancelRental = async (id: number) => {
    return await makeRequest(`/rentals/cancel/` + id, "DELETE");
  }


const RentalService = {
    createRental, getAllRentals , getRentalById, cancelRental
};

export default RentalService;