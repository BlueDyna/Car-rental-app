import { loginInput, User } from "@/types";

const url = process.env.NEXT_PUBLIC_API_URL;

const register = async(user: User)=>{
    try {
        return await fetch(url + "/auth/register", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: user ? JSON.stringify(user) : undefined,
        });
    } catch (error) {
        console.error("Error making request:", error);
        throw error;
    }
};

const login = async(user: loginInput)=>{
    try {
        return await fetch(url + "/auth/login", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: user ? JSON.stringify(user) : undefined,
        });
    } catch (error) {
        console.error("Error making request:", error);
        throw error;
    }
};


const UserService = {
    register, login
};

export default UserService;