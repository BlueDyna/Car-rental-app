import exp from "constants";
import makeRequest from "./makeRequest";
import { Rent } from "@/types";



const getAllRents = async () => {
    return await makeRequest(`/rents/all`, "GET");
}

const getRentById = async (id: number) => {
    return await makeRequest(`/rents/find/` + id, "GET");
}

const cancelRent = async (id: number) => {
    return await makeRequest(`/rents/cancel/` + id, "DELETE");
}

const getRentByEmail = async (email: string) => {
    return await makeRequest(`/rents/find/` + email, "GET");
}

const createRent = async (rent: Rent, id: number) => {
    return await makeRequest(`/rents/create/` + id, "POST", rent);
}



const RentService = {
    getAllRents,
    getRentById,
    cancelRent,
    getRentByEmail,
    createRent
}

export default RentService;