import dayjs from "dayjs";

type Status = 'ACTIVE' | 'CONFIRMED' | 'CANCELLED' | 'FINISHED' | 'PENDING'; // Adjust this based on your actual Status values


export enum Role {
    Admin = "Admin",
    // Accountant = "Accountant",
    Renter = "Renter",
    Owner = "Owner",
}

export interface Notification {
    id?: number;
    message?: string;
    rentId?: number | null;
    receiverId?: number ;
    timestamp?: dayjs.Dayjs | string;
    type?: NotificationType;
}

export enum NotificationType {
    CONFIRMATION = 'CONFIRMATION',
    CANCELATION = 'CANCELATION',
    PENDING = 'PENDING'
}


export type Car = {
    id?: number
    brand?: string;
    model?: string;
    type?: string;
    licensePlate?: string;
    numberOfSeats?: number;
    numberOfChildSeats?: number;
    haveFoldingRearSeats?: boolean;
    hasTowBar?: boolean;
    ownerMail?: string;
};

export type Rental = {
    id: number;
    startDate?: dayjs.Dayjs | string;
    endDate?: dayjs.Dayjs | string;
    city?: string;
    street?: string;
    postalCode?: number;
    email?: string;
    phoneNumber?: string;
    car?: Car;
  };

 export type Rent = {
    id?: number;
    renterPhoneNumber?: string;       
    renterMail?: string;               
    nationalRegisterNumber?: string;   
    birthDate?: dayjs.Dayjs | string;               
    drivingLicenseNumber?: string;     
    status?: Status;                   
    rental?: Rental;                   
};

export type User = {
    id: number;
    username?: string;
    password: string;
    email: string;
    role?: Role;
};

export type loginInput = {
    email: string;
    password: string;
};
  

export type StatusMessage = {
    message: string;
    type: "error" | "success";
  };
  