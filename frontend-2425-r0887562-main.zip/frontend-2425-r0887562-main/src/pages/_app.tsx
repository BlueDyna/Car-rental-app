// import { RouteGuard } from "@/components/util/RouteGuard";
import { RouteGuard } from "@/components/util/RouteGuard";
import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { useRouter } from "next/router";
import { appWithTranslation } from 'next-i18next'
import NavBar from "@/components/navbar/NavBar";
import Footer from "@/components/footer/Footer";


const App = ({ Component, pageProps }: AppProps) => {
  const { pathname } = useRouter();
  return (
    <RouteGuard>
      {(pathname !== "/login" && pathname !== "/signup") && <NavBar />}
      <Component {...pageProps} />
      {(pathname !== "/login" && pathname !== "/signup") && <Footer />}
    </RouteGuard>
  );
      
 
}
export default appWithTranslation(App);