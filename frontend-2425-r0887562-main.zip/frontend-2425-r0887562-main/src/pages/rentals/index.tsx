import NavBar from "@/components/navbar/NavBar";
import RentalOverviewTable from "@/components/rentals/RentalsOverview";
import RentalService from "@/service/RentalService";
import { Rental } from "@/types";
import dayjs from "dayjs";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useEffect, useState } from "react";

const RentalPage = () => {
  const [rentals, setRentals] = useState<Rental[]>([]);
  const [filteredRentals, setFilteredRentals] = useState<Rental[]>([]);
  const [emailFilter, setEmailFilter] = useState<string>('');
  const [carBrandFilter, setCarBrandFilter] = useState<string>('');
  const [cityFilter, setCityFilter] = useState<string>('');
  const [startDateFilter, setStartDateFilter] = useState<string>('');
  const [endDateFilter, setEndDateFilter] = useState<string>('');
  const [error, setError] = useState<string>('');
  const { t } = useTranslation();

  // Fetch all rentals on component mount
  useEffect(() => {
    const fetchRentals = async () => {
      const response = await RentalService.getAllRentals();
      const data = await response.json();
      setRentals(data);
      setFilteredRentals(data); // Initially, show all rentals
    };
    fetchRentals();
  }, []);

  // Validate that at least one filter is set
  const validateFilters = () => {
    if (
      emailFilter === '' &&
      carBrandFilter === '' &&
      cityFilter === '' &&
      startDateFilter === '' &&
      endDateFilter === ''
    ) {
      setError('You need to choose one or more values to get search results');
      return false;
    }
    setError('');
    return true;
  };

  // Filter rentals based on input values
  const handleSearch = () => {
    if (!validateFilters()) return;

    const filtered = rentals.filter(rental => {
      const matchesEmail = emailFilter
        ? rental.car?.ownerMail?.toLowerCase().includes(emailFilter.toLowerCase())
        : true;

      const matchesCarBrand = carBrandFilter
        ? rental.car?.brand?.toLowerCase().includes(carBrandFilter.toLowerCase())
        : true;

      const matchesCity = cityFilter
        ? rental.city?.toLowerCase().includes(cityFilter.toLowerCase())
        : true;

        const matchesStartDate = startDateFilter
        ? dayjs(rental.startDate) >= dayjs(startDateFilter)
        : true;
      
      const matchesEndDate = endDateFilter
        ? dayjs(rental.endDate) <= dayjs(endDateFilter)
        : true;

      return matchesEmail && matchesCarBrand && matchesCity && matchesStartDate && matchesEndDate;
    });

    setFilteredRentals(filtered);

    if (filtered.length === 0) {
      setError("No rentals found with the specified filters.");
    }
  };

  // Reset filters and show all rentals
  const handleReset = () => {
    setFilteredRentals(rentals);
    setEmailFilter('');
    setCarBrandFilter('');
    setCityFilter('');
    setStartDateFilter('');
    setEndDateFilter('');
    setError('');
  };

  return (
    <>
       <div className="max-w-7xl mx-auto px-4 py-8 bg-slate-100">
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h1 className="text-2xl font-semibold text-gray-900 mb-6">
        {t("head.title.rentals.overview")}
      </h1>

      {/* Filter Section */}
      <div className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <input
            type="text"
            placeholder="Filter by owner email"
            value={emailFilter}
            onChange={(e) => setEmailFilter(e.target.value)}
            className="w-full px-4 text-black py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors"
          />
          <input
            type="text"
            placeholder="Filter by car brand"
            value={carBrandFilter}
            onChange={(e) => setCarBrandFilter(e.target.value)}
            className="w-full text-black px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors"
          />
          <input
            type="text"
            placeholder="Filter by city"
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="w-full text-black px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors"
          />
          <input
            type="date"
            placeholder="Start Date"
            value={startDateFilter}
            onChange={(e) => setStartDateFilter(e.target.value)}
            className="w-full text-black px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors"
          />
          <input
            type="date"
            placeholder="End Date"
            value={endDateFilter}
            onChange={(e) => setEndDateFilter(e.target.value)}
            className="w-full px-4 py-2 text-black rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-colors"
          />
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleSearch}
            className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            {t("general.search")}
          </button>
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
          >
            {t("general.reset")}
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-lg">
            {error}
          </div>
        )}
      </div>

      {/* Results Section */}
      <div className="mt-6">
        {filteredRentals.length === 0 && !error ? (
          <p className="text-gray-600 text-center py-4">{t("rentals.empty")}</p>
        ) : (
          <RentalOverviewTable rental={filteredRentals} />
        )}
      </div>
    </div>
  </div>
    </>
  );
};

export default RentalPage;

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};
