import NavBar from "@/components/navbar/NavBar";
import AddRentalTable from "@/components/rentals/MakeRentalForm";
import CarService from "@/service/CarService";
import { Car } from "@/types";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";


const makeRental: React.FC = () => {
    const [car, setCar] = useState<Car | null>(null);
    const router = useRouter();
    const { carId } = router.query
    const { t } = useTranslation();

    useEffect(() => {
        const fetchCar = async () => {
            const response = await CarService.getCarById(Number(carId));
            const data = await response.json();
            setCar(data);
        };
        fetchCar();
    }, []);


  return (

    <>


      <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-sm p-6">
          <h1 className="text-2xl font-semibold text-gray-900 mb-6">{t("head.title.rentals.create")}</h1>
          
            <div className="mt-4">
              {car && <AddRentalTable car={car} />}
            </div>
          </div>
        </div>
              
      
      </>

  );

}

export default makeRental

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};
