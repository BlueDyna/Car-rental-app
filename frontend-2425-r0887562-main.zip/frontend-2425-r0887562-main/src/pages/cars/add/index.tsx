import React from 'react';
import AddCarForm from "@/components/car/AddCarForm";
import NavBar from "@/components/navbar/NavBar";
import Footer from '@/components/footer/Footer';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
import { useTranslation } from 'next-i18next';


const AddCar = () => {
  const {t } = useTranslation();


    return (
        <>


        <main className="min-h-screen bg-gray-200 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-xl mx-auto bg-white rounded-xl shadow-md p-6 space-y-6">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-6">
          {t("cars.new")}
        </h2>
        <AddCarForm />
      </div>
    </main>
                 
        </>
        

    )
}

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};




export default AddCar;

