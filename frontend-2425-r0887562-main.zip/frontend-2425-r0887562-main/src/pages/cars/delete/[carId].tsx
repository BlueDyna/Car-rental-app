import CarService from "@/service/CarService";
import { Car } from "@/types";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const RentalCancelpage = () => {
    const router = useRouter();
    const { carId } = router.query;
    const [car, setCar] = useState<Car>();
    const { t } = useTranslation();

    useEffect(() => {
        const fetchRental = async () => {
            const response = await CarService.getCarById(Number(carId));
            const data = await response.json();
            setCar(data);
        };
        if (carId) fetchRental(); // Only fetch if carId is available
    }, [carId]);

    const cancelRental = async () => {
        await CarService.deleteCar(Number(carId));
        router.push("/cars");
    };

    return (
        
           <>
                <div className="max-w-lg mx-auto p-6 bg-white rounded-lg shadow-md">
                    <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                        {t("head.title.rentals.cancel")}
                    </h2>
                    
                    <p className="text-gray-600 mb-8 text-lg">
                        {t('confirm.delete.car', {
                            brand: car?.brand,
                            model: car?.model,
                            plate: car?.licensePlate,
                        })}
                    </p>
                    
                    <div className="flex items-center justify-end space-x-4 mt-6">
                        <button
                            onClick={cancelRental}
                            className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg
                                hover:bg-red-700 transition-colors duration-200
                                focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                        >
                            {t("general.yes")}
                        </button>
                        
                        <a
                            href="/cars"
                            className="px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-lg
                                hover:bg-gray-200 transition-colors duration-200
                                focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
                        >
                            {t("general.no")}
                        </a>
                    </div>
                </div>
            </>
    
    );
};

export default RentalCancelpage;

export const getServerSideProps = async (context: any) => {
    const { locale } = context;
    return {
        props: {
            ...(await serverSideTranslations(locale ?? "en", ["common"])),
        },
    };
  };
