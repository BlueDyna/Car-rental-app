import CarOverviewTable from "@/components/car/CarOverviewTable";
import Footer from "@/components/footer/Footer";
import NavBar from "@/components/navbar/NavBar";
import CarService from "@/service/CarService";
import { Car } from "@/types";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useEffect, useState } from "react";


const CarPage = () => {
    const [cars, setCars] = useState<Car[] | [] | null>([]);


    useEffect(() => {
        const fetchCars = async () => {
            const response = await CarService.getCars();
            const data = await response.json();
            setCars(data);

        };
        fetchCars();

    }, []);

    return (
        <>
        

        <main className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">        
              <div className="max-w-7xl mx-auto">
                {cars && <CarOverviewTable car={cars} />}
              </div>
        </main>
            
           
            
            
            </>


    );

}

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};

export default CarPage;