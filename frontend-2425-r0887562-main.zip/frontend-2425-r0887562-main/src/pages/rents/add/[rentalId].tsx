import NavBar from "@/components/navbar/NavBar";
import AddRentTable from "@/components/rents/RentsMakeForm";
import RentalService from "@/service/RentalService";
import RentService from "@/service/RentService";
import { Rental } from "@/types";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";


const makeRental: React.FC = () => {
  const { t } = useTranslation();
    const [car, setCar] = useState<Rental | null>(null);
    const router = useRouter();
    const { rentalId } = router.query

    useEffect(() => {
        const fetchCar = async () => {
            const response = await RentalService.getRentalById(Number(rentalId));
            const data = await response.json();
            setCar(data);
        };
        fetchCar();
    }, []);


  return (

  <>
    
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h1 className="text-2xl font-semibold text-gray-900 mb-6">
          {t("head.title.rents.create")}
        </h1>
        
        <div className="mt-4">
          {car && <AddRentTable rental={car} />}
        </div>
      </div>
    </div>
      
      
  </>

  );

}

export default makeRental

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};