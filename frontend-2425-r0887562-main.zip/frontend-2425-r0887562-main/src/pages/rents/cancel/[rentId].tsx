import RentalService from "@/service/RentalService"
import RentService from "@/service/RentService"
import { Rent, Rental } from "@/types"
import dayjs from "dayjs"
import { useTranslation } from "next-i18next"
import { serverSideTranslations } from "next-i18next/serverSideTranslations"
import { useRouter } from "next/router"
import { useEffect, useState } from "react"


const RentCancelpage = () => {    
    const { t } = useTranslation();
    const router = useRouter()
    const { rentId } = router.query
    const [rent, setRental] = useState<Rent>()

    useEffect(() => {
        const fetchRental = async () => {
            const response = await RentService.getRentById(Number(rentId));
            const data = await response.json();
            setRental(data);
        }
        fetchRental();
    }, []);

    const cancelRent = async () => {
       const response = await RentService.cancelRent(Number(rentId));
        router.push("/rentals");
    }

    return(
        <>
        <h2 className="text-xl font-bold mb-4 text-gray-800">{t("head.title.rentals.cancel")}</h2>
             
        <p className="mb-4 text-black"> 
          {t('rent.cancel.', {
            brand: rent?.rental?.car?.brand,
            model: rent?.rental?.car?.model,
            plate: rent?.rental?.car?.licensePlate,
            startDate: dayjs(rent?.rental?.startDate).format("DD/MM/YYYY"),
            endDate: dayjs(rent?.rental?.endDate).format("DD/MM/YYYY"),
          })}
        </p>
        <div className="flex space-x-4">
          <button 
            onClick={cancelRent} 
            className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            {t("general.yes")}
          </button>
          <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">
            <a href="/rents">{t("general.no")}</a>
          </button>
        </div>
      </>
    )

}

export default RentCancelpage

export const getServerSideProps = async (context: any) => {
    const { locale } = context;
    return {
        props: {
            ...(await serverSideTranslations(locale ?? "en", ["common"])),
        },
    };
  };