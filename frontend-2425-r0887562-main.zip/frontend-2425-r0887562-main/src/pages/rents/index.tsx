import NavBar from "@/components/navbar/NavBar";
import RentsOverviewTable from "@/components/rents/RentsOverviewTable";
import RentService from "@/service/RentService";
import { Rent } from "@/types";
import { t } from "i18next";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useEffect, useState } from "react";

const RentPage  = () => {
    const [rentals, setRentals] = useState<Rent[]>([]);
    const [filteredRentals, setFilteredRentals] = useState<Rent[]>([]);
    const [emailFilter, setEmailFilter] = useState<string>('');
    const [error, setError] = useState<string>('');
    const { t } = useTranslation();
  
    // Fetch all rents on component mount
    useEffect(() => {
      const fetchRentals = async () => {
        const response = await RentService.getAllRents();
        const data = await response.json();
        setRentals(data);
        setFilteredRentals(data); // Initially, show all rentals
      };
      fetchRentals();
    }, []);

    // Validate email input
    const validate = () => {
      if (emailFilter === '') {
        setError('You need to choose one or more values to get search results');
        return false;
      }
      setError('');
      return true;
    };
  
    // Filter rentals based on the input value (both owner and renter emails)
    const handleSearch = () => {

        if (!validate()) {
            return;
        }
      const filtered = rentals.filter(rent =>
        emailFilter === '' ||
        rent.rental?.email?.toLowerCase().includes(emailFilter.toLowerCase()) ||
        rent.renterMail?.toLowerCase().includes(emailFilter.toLowerCase())
      );
      setFilteredRentals(filtered);
    };
  
    return (
      <>
      <div className="container mx-auto px-4 py-6 bg-slate-100">
        <main>
          <h1 className="text-2xl font-bold mb-6 text-gray-800">
            {t("head.title.rents.overview")}
          </h1>
     
          {/* Single Input Filter Form */}
          <div className="mb-6 flex items-center space-x-4">
            <input
              type="text"
              placeholder="Filter by owner's or renter's email"
              value={emailFilter}
              onChange={(e) => setEmailFilter(e.target.value)}
              className="flex-grow px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button 
              onClick={handleSearch}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              {t("general.search")}
            </button>
            <button 
              onClick={() => setFilteredRentals(rentals)}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
            >
              {t("general.reset")}
            </button>
          </div>
     
          {/* Error Handling */}
          {error && (
            <div className="mb-4 text-red-500 text-sm">{error}</div>
          )}
     
          {/* Rents Overview Table */}
          {filteredRentals.length === 0 ? (
            <p className="text-gray-600">{t("rent.overview.norents")}</p>
          ) : (
            <RentsOverviewTable rent={filteredRentals} />
          )}
        </main>
      </div>
    </>
    );
  };
  

export default RentPage;

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};
