import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import LoginForm from "@/components/auth/LoginForm";


const LoginPage = () => {

  return (
    <div className="min-h-screen">
      <LoginForm />
    </div>
  );
};

export const getServerSideProps = async (context: any) => {
  try {
    const { locale = "en" } = context; // Explicitly set fallback locale
    return {
      props: {
        ...(await serverSideTranslations(locale, ["common"])),
      },
    };
  } catch (error) {
    console.error("Error loading translations:", error);
    return {
      props: {
        // Provide a fallback in case of errors
        error: true,
      },
    };
  }
};

  export default LoginPage;