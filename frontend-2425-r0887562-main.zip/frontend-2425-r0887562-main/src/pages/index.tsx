import Footer from "@/components/footer/Footer";
import NavBar from "@/components/navbar/NavBar"
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";


export default function Home() {
  const { t } = useTranslation();
  return (
    <>
      <main className="min-h-screen bg-gradient-to-b from-red-500 to-white flex items-center justify-center p-6 bg-no-repeat bg-cover"
  style={{
    backgroundImage: `url('/images/car-rental-copyright-free.jpeg')`,
  }}
>
        <div className="bg-slate-100 bg-opacity-80 p-8 rounded-lg shadow-lg text-center max-w-lg">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">{t("general.welcome")}</h1>
      </div>
</main>


    </>);
}

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};
