import SignUpForm from "@/components/auth/SignUpForm";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";

const signupPage = () => {
    return (
        <>
        <main className="flex justify-center items-center min-h-screen bg-gray-100 p-4">
          <div className="w-full max-w-md bg-white shadow-md rounded-lg p-8">
            <SignUpForm />
          </div>
        </main>
      </>
    );
}

export const getServerSideProps = async (context: any) => {
    const { locale } = context;
    return {
        props: {
            ...(await serverSideTranslations(locale ?? "en", ["common"])),
        },
    };
  };
 export default signupPage   