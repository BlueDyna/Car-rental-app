import Footer from "@/components/footer/Footer";
import NavBar from "@/components/navbar/NavBar";
import NotificationOverviewTable from "@/components/notification/NotificationOverviewTable";
import RentsOverviewTable from "@/components/rents/RentsOverviewTable";
import NotificationService from "@/service/NotificationService";
import RentService from "@/service/RentService";
import { Notification, Rent } from "@/types";
import { useTranslation } from "next-i18next";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useEffect, useState } from "react";

const NotificationPage  = () => {
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [error, setError] = useState<string>('');
    const { t } = useTranslation();
  
    // Fetch all rents on component mount
    useEffect(() => {
      const fetchRentals = async () => {
        const response = await NotificationService.getNotifications();
        const data = await response.json();
        setNotifications(data);
       // Initially, show all rentals
      };
      fetchRentals();
    }, []);

    // Validate email input
    return (
      <>
      <div className="min-h-screen bg-gray-50">
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-black mb-2">
                {t("head.title.notifications.")}
              </h1>
              <div className="h-1 w-20 bg-orange-600 rounded"></div>
            </div>
    
            <div className="mt-6">
              {notifications.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <div className="flex flex-col items-center">
                    <svg
                      className="w-12 h-12 text-gray-400 mb-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                      />
                    </svg>
                    <p className="text-gray-600 text-lg">
                      {t("notifications.empty")}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="rounded-lg overflow-hidden">
                  <NotificationOverviewTable notification={notifications} />
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </>
    );
  };
  

export default NotificationPage;

export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};
