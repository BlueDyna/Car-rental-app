import NotificationService from '@/service/NotificationService';
import { Notification } from '@/types';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
import { useRouter } from 'next/router';
import React, { useState, useEffect } from 'react';

const NotificationComponent: React.FC = () => {
  const [notification, setNotification] = useState<Notification>();
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { notifId } = router.query;
  const {t} = useTranslation();
  const role = sessionStorage.getItem('role');

  // Fetch the notification by ID
  const fetchNotification = async () => {
    setLoading(true);
    setError(null);

    try {
      const result = await NotificationService.findNotificationById(Number(notifId));
      const data = await result.json();
      setNotification(data);
    } catch (err) {
      setError('Failed to load notification.');
    } finally {
      setLoading(false);
    }
  };

  // Confirm the notification with a "Yes" or "No"
  const handleConfirm = async (answer: boolean) => {
    try {
     const response = await NotificationService.confirmYesorNo(Number(notifId), answer);
     const data = await response.json();
     if (data.ok) {
       router.push('/notification');
     } else {
        setError('Failed to confirm notification.');
      }
    } catch (err) {
      setError('Failed to confirm notification.');
    }
  };

  useEffect(() => {
    if (notifId) fetchNotification();
  }, [notifId]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
  if (!notification) return <div>No notification found.</div>;

  return (
    <div className="p-4 border rounded-md bg-gray-50">
      <h3 className="text-lg font-bold mb-2 text-black">{notification.type}</h3>
      <p className="mb-4 text-black">{notification.message}</p>
      
      {notification?.type === 'PENDING' && role !== "Renter" ? (
        <div className="flex gap-4">
          <button
            onClick={() => handleConfirm(true)}
            className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
          >
             {t("general.yes")}
          </button>
          <button
            onClick={() => handleConfirm(false)}
            className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
          >
           {t("general.no")}
          </button>
        </div>
      ) : (
       <p></p>
      )}
    </div>
  );
};

export default NotificationComponent;


export const getServerSideProps = async (context: any) => {
  const { locale } = context;
  return {
      props: {
          ...(await serverSideTranslations(locale ?? "en", ["common"])),
      },
  };
};
